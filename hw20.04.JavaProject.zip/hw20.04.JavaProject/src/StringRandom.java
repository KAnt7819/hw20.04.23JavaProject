import java.util.Random;

public class StringRandom {
    private static final Random RANDOM = new Random();
    private static final String ALPHABET = "abcdefghijklmnopqrstuvwxyz";

    public static String generateWord(int length) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < length; i++) {
            char c = ALPHABET.charAt(RANDOM.nextInt(ALPHABET.length()));
            sb.append(c);
        }
        return sb.toString();
    }

    public static String generateSentence(int length) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < length; i++) {
            sb.append(generateWord(RANDOM.nextInt(10) + 1));
            if (i < length - 1) {
                sb.append(' ');
            }
        }
        sb.append(getRandomPunctuation());
        return sb.toString();
    }

    public static String generateText(int numSentences) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < numSentences; i++) {
            sb.append(generateSentence(RANDOM.nextInt(20) + 1));
            sb.append(' ');
        }
        return sb.toString();
    }

    private static char getRandomPunctuation() {
        char[] punctuation = {'.', '?', '!', '…'};
        return punctuation[RANDOM.nextInt(punctuation.length)];
    }
}

