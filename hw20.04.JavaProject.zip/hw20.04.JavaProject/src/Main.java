import java.util.Random;
import java.util.Scanner;

// 1 уровень сложности: Напишите аналог Random для генерации строк - StringRandom.
// В классе реализуйте набор публичных статических методов: первый метод генерирует слово заданной длины,
// состоящее из  английских букв (любой набор букв). Второй метод генерирует предложение из заданного количества разных слов.
// Третий метод генерирует текст из заданного количества разных предложений, разделяя предложения случайными знаками препинания из набора (. или ! или ? или …).
// В методе main сгенерируйте текст из 1000 предложений.
public class Main {
    public static void main(String[] args) {
        System.out.println(StringRandom.generateText(5));
        System.out.println(StringRandom.generateSentence(10));
        System.out.println(StringRandom.generateText(1000));
        System.out.println();
    }
}
